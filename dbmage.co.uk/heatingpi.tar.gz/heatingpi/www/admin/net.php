<body style="background-color: black; width: 842px; float: left;">
<table>
<tr>
<td><img src='moni/imgs/net01.1day.png'></td>
<td><img src='moni/imgs/net02.1day.png'>
<img src='moni/imgs/net03.1day.png'></td>
</tr>
</table>
</body>
